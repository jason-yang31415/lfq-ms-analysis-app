import matplotlib.pyplot as plt
import numpy as np


def volcano(data, subsets, ax=None):
    """
    make a volcano plot

    :param data: dataframe containing comparison data
    :param subsets: list of subsets of points to have different formatting, as tuples (set, plotting kwargs, lookup)
    :param ax: axes to plot on
    """
    layers = [
    ]  # list of layers of points (set, plotting kwargs) with distinct points
    prev = set()  # set of points already plotted on previous layers
    for s in subsets[::-1]:  # iterate from last subset backwards
        if s[2] is None:
            # subtract points already plotted on previous layers
            layers.append((s[0]-prev, s[1]))
        else:
            layers.append((
                set(data[data[s[2]].apply(lambda x: type(x) == str and (
                    x in s[0]-prev or any([a in s[0]-prev for a in x.split(";")])))].index),
                s[1]
            ))  # lookup points to get index, then subtract points already plotted on previous layers
        prev |= s[0]  # add current layer's points to prev
    if ax is None:
        ax = plt.gca()
    # iterate from last layer backwards so that the last subset is plotted on top
    for s in layers[::-1]:
        ax.scatter(data.loc[s[0]]["log FC"], -
                   np.log10(data.loc[s[0]]["p adjusted"]), **s[1])
